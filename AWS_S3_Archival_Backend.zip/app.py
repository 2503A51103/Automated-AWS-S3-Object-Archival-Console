from flask import Flask, render_template
import boto3

app = Flask(__name__)
s3 = boto3.client('s3', region_name='us-east-1')

SOURCE_BUCKET = 'my-active-button-product-04'
ARCHIVE_BUCKET = 'my-archive-button-product-04'

@app.route('/', methods=['GET'])
def index():
    return render_template('index.html')

@app.route('/archive', methods=['POST'])
def archive_files():
    try:
        response = s3.list_objects_v2(Bucket=SOURCE_BUCKET)
        if 'Contents' not in response:
            return render_template('index.html', message='No active files found in source bucket.')
        moved_count = 0
        for obj in response['Contents']:
            key = obj['Key']
            s3.copy_object(Bucket=ARCHIVE_BUCKET, CopySource={'Bucket': SOURCE_BUCKET, 'Key': key}, Key=key)
            s3.delete_object(Bucket=SOURCE_BUCKET, Key=key)
            moved_count += 1
        return render_template('index.html', message=f'Success! {moved_count} file(s) archived to {ARCHIVE_BUCKET}.')
    except Exception as e:
        return render_template('index.html', message=f'Error during archival: {str(e)}')

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000)
