# AWS S3 Archival Console Backend

## Project Details
- **Course:** 25CAI102PC205 - Cloud Computing (SR University)
- **Team Leader:** Sanjana. D (2503A51103)
- **Team Members:** T. Geethika (2503A51112), K. Suchithra (2503A51114), B. Tejaswi (2503A51094), B. Jashwanth (2503A51091)

## Quick Start
1. Install dependencies:
   ```bash
   pip install -r requirements.txt
   ```
2. Run the application:
   ```bash
   python3 app.py
   ```
3. Access in browser:
   ```text
   http://<EC2-IP>:5000
   ```
